package gen

//go:generate protoc --go_out=. char.proto
